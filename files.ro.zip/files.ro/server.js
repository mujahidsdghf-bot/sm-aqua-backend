const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

// MongoDB Atlas URL (later replace)
mongoose.connect("YOUR_MONGODB_URL")
.then(()=>console.log("DB Connected"));

const OrderSchema = new mongoose.Schema({
    name: String,
    phone: String,
    product: String,
    date: { type: Date, default: Date.now }
});

const Order = mongoose.model("Order", OrderSchema);

// Save order
app.post("/order", async (req, res) => {
    const order = new Order(req.body);
    await order.save();
    res.json({message:"saved"});
});

// Get orders
app.get("/orders", async (req, res) => {
    const data = await Order.find().sort({date:-1});
    res.json(data);
});

// Delete
app.delete("/order/:id", async (req,res)=>{
    await Order.findByIdAndDelete(req.params.id);
    res.json({message:"deleted"});
});

app.listen(3000, ()=>console.log("Server running"));